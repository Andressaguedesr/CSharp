﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClothesInventoryControl.cs
{
    public enum ShoesType
    {
        Sneakers, Sandal
    }
}
